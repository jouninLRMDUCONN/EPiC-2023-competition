This is the default directory for storing data used in the `explain_data.ipynb` notebook.
If you want to run the notebook you need to either put the data here, or change data paths in code cells.
